<?php
// jjohnston php ajax shopping cart template to update inventories
die('<pre>'.print_r($_POST,true));
